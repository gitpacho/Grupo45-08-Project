import { Router } from 'express';
import mongoose from 'mongoose';
const Schema = mongoose.Schema;

const gruposSchema = new Schema({
    nombre: {type: String, required:[true,"Nombre obligatorio"]},
    sexo: String,
    grupo: String,
    detalle: String,
    date: {type: Date, default: Date.now},
    activo:{type:Boolean, default:true}
});


//convertir modelo
const primerDB = mongoose.model('primerDB', gruposSchema);
export default primerDB;