import express from 'express';
const router = express.Router();

// importar el modelo nota

import PrimerDB from '../models/primerDB';

//Agregar registro
router.post('/nuevo-registro', async (req, res) => {
    const body = req.body;
    try {
        const PrimeraDB = await PrimerDB.create(body);
        res.status(200).json(PrimeraDB)
    } catch (error) {
        return res.status(500).json({
            mensaje: 'ocurrió algo inesperado',
            error
        })
    }
});

// Get buscar todos los registros
router.get('/buscarTodo', async (req, res) => {
    try {
        const PrimeraDB = await PrimerDB.find();
        res.json(PrimeraDB)
    } catch (error) {
        return res.status(400).json({
            mensaje: "Error en la busqueda",
            error
        })
    }
})

// Get buscar por parámetro grupo

router.get('/buscarParametro/:id', async (req, res) => {
    const _id = req.params.id;
    try {
        const PrimeraDB = await PrimerDB.findOne({ _id });
        res.json(PrimeraDB)
    } catch (error) {
        return res.status(400).json({
            mensaje: "Error en la busqueda de parámetro",
            error
        })
    }
})


// Eliminar Parámetro

router.delete('/eliminarParametro/:id', async (req, res) => {
    const _id = req.params.id;
    try {
        const PrimeraDB = await PrimerDB.findByIdAndDelete({ _id });
        if (!PrimeraDB) {
            return res.status(400).json({
                mensaje: "no se encontró el parámetro",
                error
            })

        }
        res.json(PrimeraDB)
    } catch (error) {
        return res.status(400).json({
            mensaje: "ocurrió un error eliminando el id",
            error
        })
    }
});

//put actualizar parámetro

router.put('/actualizarParametro/:id', async (req, res) => {
    const _id = req.params.id;
    const body = req.body;
    try {
        const PrimeraDB = await PrimerDB.findByIdAndUpdate(
        _id,
        body, { new: true });
        res.json(PrimeraDB);
    } catch (error) {
        return res.status(400).json({
            mensaje: "ocurrió un error actualizando el id",
            error
        })
    }
});


//exportar la configuracion de express
module.exports = router;